#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

int main(int argc, const char** argv) 
{
	// 计算机随机生成一个数字n
	srand(time(0));
	int randomNumber = rand();

	do {
		// 然后提示用户猜这个数字是多少
		cout << .... << endl;
		int number;
		cin >> number;

		// 如果n>a则输出提示，“您输入的数字过小”
		if (randomNumber > number) {
			// ...
			cout << ... << endl;
		} else if (randomNumber < number) {
			// ...
			cout << ... << endl;
		} else {
			cout << ... << endl;
			break;
		}
	} while (true);

	return 0;
}