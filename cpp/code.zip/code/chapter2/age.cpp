/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This is the print age program.
 */

#include <iostream>

int main(int argc, const char** argv) {
    int myAge;
    std::cout << "Please input your age: " << std::endl;
    std::cin >> myAge;
    std::cout << "You are " << myAge << " years old." << std::endl;
    return 0;
}