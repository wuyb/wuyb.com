/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This is the sizeof program.
 */

#include <iostream>

using namespace std;

int main(int argc, const char** argv) {
    cout << "sizeof(bool) = " << sizeof(bool) << endl;
    cout << "sizeof(char) = " << sizeof(char) << endl;
    cout << "sizeof(short) = " << sizeof(short) << endl;
    cout << "sizeof(int) = " << sizeof(int) << endl;
    cout << "sizeof(float) = " << sizeof(float) << endl;
    cout << "sizeof(double) = " << sizeof(double) << endl;
    cout << "sizeof(long double) = " << sizeof(long double) << endl;

    cout << endl;

    int anInt;
    cout << "sizeof(anInt) = " << sizeof(anInt) << endl;
    return 0;
}