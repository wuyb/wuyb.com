/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of condition operator.
 */

#include <iostream>

void printOld()
{
    std::cout << "You are old ... " << std::endl;
}

void printYoung()
{
        std::cout << "You are young! " << std::endl;
}

int main(int argc, const char** argv) {

    int myAge;
    std::cout << "Please enter your age : " << std::endl;
    std::cin >> myAge;

    const char * message = (myAge > 30) ? "You are old ... " : "You are young! ";
    std::cout << message << std::endl;

    myAge > 30 ? printOld() : printYoung();

    char c;
    std::cin >> c;
    return 0;
}