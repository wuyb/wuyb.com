/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of if .
 */

#include <iostream>

int main(int argc, const char** argv) {

    int myAge;
    std::cout << "Please enter your age : " << std::endl;
    std::cin >> myAge;

    if (myAge > 30) {
        std::cout << "You are old ... " << std::endl;
    }

    char c;
    std::cin >> c;
    return 0;
}