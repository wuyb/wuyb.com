/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This is the hello world program.
 */

#include <iostream>

int main(int argc, const char** argv) {
    std::cout << "Hello world!" << std::endl;
    return 0;
}