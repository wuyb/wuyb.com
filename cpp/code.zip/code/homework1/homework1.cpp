#include <iostream>

using namespace std;

int main(int argc, const char** argv) 
{
	// 提示用户输入一个数字
	cout << "Please input a number " << endl;

	int number;
	// 待用户输入后
	cin >> number;

	// 计算该数字的平方
	int square;
	square = number * number;

	// 三次方
	int square3;
	square3 = ...;

	// 并依次输出
	cout << ... << endl;
	cout << ... << endl;

	// 然后计算从1到这个数字之间共有多少个数可以被三整除
	int total = 0;

	for (int i = 1; i <= number; i++) {
		// ???
	}
}