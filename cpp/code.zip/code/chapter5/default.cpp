/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the function default argument.
 */

#include <iostream>

using namespace std;

void delay(int a = 2) {
    cout << "Delayed : " << a << " second" << endl;
}

int main(int argc, const char** argv) {
    delay();
    delay(2);
    delay(100);

    char a[5] = {"hel"};
    char b[5] = {"hel"};
    char d[5] = "hel";

    char c;
    std::cin >> c;
    return 0;
}