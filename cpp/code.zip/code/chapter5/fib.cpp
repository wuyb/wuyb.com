/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the recursive functions.
 */

#include <iostream>

using namespace std;

long fib(int n) {
    if (n == 1) {
        return 1;
    } else if (n == 0) {
        return 1;
    }
    return fib(n - 2) + fib(n - 1);
}

int main(int argc, const char** argv) {

    for (int i = 0; i <= 10; i++) {
        cout << "fib(" << i << ")=" << fib(i) << endl;
    }

    char c;
    std::cin >> c;
    return 0;
}