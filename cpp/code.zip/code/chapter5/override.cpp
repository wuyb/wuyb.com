/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the function override.
 */

#include <iostream>

using namespace std;

void print(int a) {
    cout << "Integer : " << a << endl;
}

void print(double a) {
    cout << "Double : " << a << endl;
}

int main(int argc, const char** argv) {

	cout << argc << endl;
	cout << argv[0] << endl;
	cout << argv[1] << endl;
	cout << argv[2] << endl;

    print(1);
    print(1.0);

    char c;
    std::cin >> c;
    return 0;
}