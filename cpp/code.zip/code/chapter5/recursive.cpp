/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the recursive functions.
 */

#include <iostream>

using namespace std;

long fact(int n) {
    if (n == 1) {
        return 1;
    }
    return fact(n - 1) * n;
}

int main(int argc, const char** argv) {

    cout << "fact(10)=" << fact(10) << endl;

    char c;
    std::cin >> c;
    return 0;
}