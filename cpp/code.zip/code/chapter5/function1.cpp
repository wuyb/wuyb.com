/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of function.
 */

#include <iostream>

using namespace std;

void printWelcomeMessage();

void printWelcomeMessage() {
    cout << "Welcome to C++ Programming!" << endl;
}

int add(int, int);

int add(int a, int b) {
    return a + b;
}

void printAge(int age);
void printAge(int age) {
    cout << "Your age is " << age << endl;
}

int main(int argc, const char** argv) {

    printWelcomeMessage();

    cout << "1+1=" << add(1, 1) << endl;

    printAge(20);

    char c;
    std::cin >> c;
    return 0;
}