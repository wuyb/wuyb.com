/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the calculation of pi.
 */

#include <iostream>
#include <iomanip>
#include <cmath>

int main(int argc, const char** argv) {
    double sum = 0.0;
    double element = 1;
    double sign = 1;
    double k = 1;

    while (fabs(element) > 0.0000001) {
        element = 1 / k * sign;
        sum += element;

        k += 2;
        sign *= -1;
    }

    double pi  = sum * 4;
    std::cout << " result : " << std::setiosflags(std::ios::fixed) << std::setprecision(6) << pi << std::endl;

    char c;
    std::cin >> c;
    return 0;
}