/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of for operator.
 */

#include <iostream>


int main(int argc, const char** argv) {
    int start;
    int end;
    std::cout << "enter start: " << std::endl;
    std::cin >> start;
    std::cout << "enter end: " << std::endl;
    std::cin >> end;

    int total = 0;
    for (int i = start; i <= end; i++) {
        total += i;
    }

    std::cout << " sum " << start << " to " << end << " : " << total << std::endl;

    char c;
    std::cin >> c;
    return 0;
}