/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the calculation of pi.
 */

#include <iostream>
#include <iomanip>
#include <cmath>

int main(int argc, const char** argv) {

    double sum = 0.0;
    for (int k = 1;;k++) {
        double element =  (k % 2 == 0 ? -1 : 1) * 1 / ((double) (2 * k - 1));
        sum += element;
        if (fabs(element) < 0.0000001) {
            break;
        }
    }

    double pi  = sum * 4;
    std::cout << " result : " << std::setiosflags(std::ios::fixed) << std::setprecision(6) << pi << std::endl;

    char c;
    std::cin >> c;
    return 0;
}