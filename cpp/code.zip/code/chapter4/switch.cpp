/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of switch operator.
 */

#include <iostream>


int main(int argc, const char** argv) {

    int a;
    std::cout << "Please enter a number in [1, 4] : " << std::endl;
    std::cin >> a;

    switch (a)
    {
        case 1:
            std::cout << "You entered 1" << std::endl;
            break;
        case 2:
            std::cout << "You entered 2" << std::endl;
            break;
        case 3:
            std::cout << "You entered 3" << std::endl;
            break;
        case 4:
            std::cout << "You entered 4" << std::endl;
            break;
        default:
            std::cout << "It should be between 1 and 4" << std::endl;
            break;
    }

    char c;
    std::cin >> c;
    return 0;
}