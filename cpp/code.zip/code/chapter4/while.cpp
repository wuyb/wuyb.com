/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of while operator.
 */

#include <iostream>

// find the first integer that can be divided by 3 and larger than start
int main(int argc, const char** argv) {
    int start;
    std::cout << "enter start: " << std::endl;
    std::cin >> start;

    while (start % 3 != 0) {
        start++;
    }

    std::cout << " result : " << start << std::endl;

    char c;
    std::cin >> c;
    return 0;
}