/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program determines whether a given number is prime.
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main(int argc, const char** argv) {

    unsigned int n;
    cout << "Please enter a number : " << endl;
    cin >> n;

    bool isPrime = true;
    unsigned int k = 2;
    while (1) {
        if (n % k == 0) {
            isPrime = false;
            break;
        }
        if (k > sqrt(n)) {
            break;
        }
        k++;
    }
    cout << n << (isPrime ? " is " : " isn't ") << "prime " << endl;

    char c;
    std::cin >> c;
    return 0;
}