/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the useage of for operator.
 */

#include <iostream>


int main(int argc, const char** argv) {
    int total = 0;
    for (int i = 1; i <= 100; i++) {
        total += i;
    }

    std::cout << " sum 1 to 100 : " << total << std::endl;

    char c;
    std::cin >> c;
    return 0;
}