/**
 * Beijing Jiaotong University. All Rights Reserved.
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

bool isPrime(unsigned int n) {
    bool isPrime = true;
    unsigned int k = 2;
    while (1) {
        if (n % k == 0 && k != 2) {
            isPrime = false;
            break;
        }
        if (k > sqrt(n)) {
            break;
        }
        k++;
    }
    return isPrime;
}

int main(int argc, const char** argv) {

    unsigned int n;
    do {
        cout << "Please enter a prime number: " << endl;
        cin >> n;
    } while (!isPrime(n));

    cout << "Well done!" << endl;

    char c;
    std::cin >> c;
    return 0;
}