/**
 * Beijing Jiaotong University. All Rights Reserved.
 *
 * This program demonstrates the array usage.
 */

#include <iostream>

using namespace std;

int main(int argc, const char** argv) {

    int a[100];

    for (int i = 0; i < 100; i++) {
        a[i] = i * 2;
    }

    for (int i = 0; i < 100; i++) {
        cout << "a[i]=" << a[i] << " ";
        if (i % 8 == 0) {
            cout << endl;
        }
    }

    cout << endl;

    char c;
    std::cin >> c;
    return 0;
}